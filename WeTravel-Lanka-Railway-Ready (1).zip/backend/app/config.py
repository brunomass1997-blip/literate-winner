from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    app_name: str = "WeTravel Lanka"
    secret_key: str = "change-this"
    database_url: str = "sqlite:///./wetravel.db"
    access_token_minutes: int = 720
    admin_phone: str = "94770000000"
    admin_password: str = "ChangeMe123!"
    otp_mode: str = "dev"

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
