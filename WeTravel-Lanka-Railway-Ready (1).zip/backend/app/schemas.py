from pydantic import BaseModel, Field

class RegisterIn(BaseModel):
    full_name: str = Field(min_length=2, max_length=120)
    phone: str = Field(min_length=7, max_length=32)
    password: str = Field(min_length=8, max_length=128)
    otp: str = Field(min_length=4, max_length=10)

class LoginIn(BaseModel):
    phone: str
    password: str

class OTPRequest(BaseModel):
    phone: str
    purpose: str = "register"

class ReviewIn(BaseModel):
    rating: int = Field(ge=1, le=5)
    review: str = Field(min_length=3, max_length=500)

class BookingIn(BaseModel):
    title: str
    location: str
    nights: str
    guests: str
    room: str
    price_lkr: int = Field(ge=0)
    image_url: str
    description: str
    is_active: bool = True

class UserFreezeIn(BaseModel):
    is_frozen: bool
