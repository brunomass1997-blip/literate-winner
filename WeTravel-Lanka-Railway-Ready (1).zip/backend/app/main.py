from datetime import datetime, timedelta
from pathlib import Path
from fastapi import FastAPI, Depends, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from sqlalchemy import desc

from .config import settings
from .database import Base, engine, get_db, SessionLocal
from .models import User, BookingTemplate, CompletedBooking, OTPCode
from .schemas import RegisterIn, LoginIn, OTPRequest, ReviewIn, BookingIn, UserFreezeIn
from .security import hash_password, verify_password, create_token, current_user, admin_user
from .otp_provider import generate_otp, send_otp
from .seed import seed

app = FastAPI(title=settings.app_name)

Base.metadata.create_all(bind=engine)
with SessionLocal() as db:
    seed(db)

FRONTEND = Path(__file__).resolve().parents[2] / "frontend"
app.mount("/assets", StaticFiles(directory=FRONTEND / "assets"), name="assets")

@app.get("/")
def home():
    return FileResponse(FRONTEND / "index.html")

@app.get("/login.html")
def login_page():
    return FileResponse(FRONTEND / "login.html")

@app.get("/register.html")
def register_page():
    return FileResponse(FRONTEND / "register.html")

@app.get("/admin.html")
def admin_page():
    return FileResponse(FRONTEND / "admin.html")

@app.post("/api/auth/request-otp")
def request_otp(data: OTPRequest, db: Session = Depends(get_db)):
    code = generate_otp()
    db.add(OTPCode(phone=data.phone, code=code, purpose=data.purpose))
    db.commit()
    send_otp(data.phone, code)
    result = {"ok": True, "message": "OTP sent"}
    if settings.otp_mode == "dev":
        result["dev_otp"] = code
    return result

@app.post("/api/auth/register")
def register(data: RegisterIn, db: Session = Depends(get_db)):
    if db.query(User).filter(User.phone == data.phone).first():
        raise HTTPException(status_code=409, detail="Phone already registered")

    cutoff = datetime.utcnow() - timedelta(minutes=10)
    otp = (db.query(OTPCode)
           .filter(OTPCode.phone == data.phone, OTPCode.purpose == "register",
                   OTPCode.used == False, OTPCode.created_at >= cutoff)
           .order_by(desc(OTPCode.id)).first())
    if not otp or otp.code != data.otp:
        raise HTTPException(status_code=400, detail="Invalid or expired OTP")

    otp.used = True
    user = User(full_name=data.full_name, phone=data.phone, password_hash=hash_password(data.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    return {"access_token": create_token(user), "token_type": "bearer"}

@app.post("/api/auth/login")
def login(data: LoginIn, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.phone == data.phone).first()
    if not user or not verify_password(data.password, user.password_hash):
        raise HTTPException(status_code=401, detail="Invalid phone or password")
    if user.is_frozen:
        raise HTTPException(status_code=403, detail="Account is frozen")
    return {"access_token": create_token(user), "token_type": "bearer",
            "user": {"id": user.id, "full_name": user.full_name, "phone": user.phone, "is_admin": user.is_admin}}

@app.get("/api/me")
def me(user: User = Depends(current_user)):
    return {"id": user.id, "full_name": user.full_name, "phone": user.phone,
            "is_admin": user.is_admin, "is_frozen": user.is_frozen}

@app.get("/api/member/dashboard")
def member_dashboard(user: User = Depends(current_user), db: Session = Depends(get_db)):
    completed = db.query(CompletedBooking).filter(CompletedBooking.user_id == user.id).order_by(CompletedBooking.id).all()
    active = db.query(BookingTemplate).filter(BookingTemplate.is_active == True).order_by(BookingTemplate.id).all()
    if not active:
        raise HTTPException(status_code=404, detail="No active bookings configured")

    idx = len(completed) % len(active)
    current = active[idx]
    avg = round(sum(x.rating for x in completed) / len(completed), 1) if completed else 0.0
    history = []
    for item in reversed(completed[-10:]):
        template = db.get(BookingTemplate, item.template_id)
        history.append({
            "id": item.id,
            "title": template.title if template else "Booking",
            "location": template.location if template else "",
            "rating": item.rating,
            "review": item.review,
            "completed_at": item.completed_at.isoformat()
        })

    return {
        "completed_count": len(completed),
        "average_rating": avg,
        "reviews_count": len(completed),
        "round_progress": len(completed) % 20,
        "current_booking": booking_dict(current),
        "history": history
    }

@app.post("/api/member/complete-current")
def complete_current(data: ReviewIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    completed_count = db.query(CompletedBooking).filter(CompletedBooking.user_id == user.id).count()
    active = db.query(BookingTemplate).filter(BookingTemplate.is_active == True).order_by(BookingTemplate.id).all()
    if not active:
        raise HTTPException(status_code=404, detail="No active bookings configured")
    current = active[completed_count % len(active)]

    record = CompletedBooking(
        user_id=user.id,
        template_id=current.id,
        rating=data.rating,
        review=data.review
    )
    db.add(record)
    db.commit()
    db.refresh(record)
    return {"ok": True, "completed_booking_id": record.id}

@app.get("/api/admin/overview")
def admin_overview(_: User = Depends(admin_user), db: Session = Depends(get_db)):
    users = db.query(User).filter(User.is_admin == False).count()
    frozen = db.query(User).filter(User.is_admin == False, User.is_frozen == True).count()
    bookings = db.query(BookingTemplate).count()
    reviews = db.query(CompletedBooking).count()
    return {"users": users, "frozen_users": frozen, "booking_templates": bookings, "reviews": reviews}

@app.get("/api/admin/users")
def admin_users(_: User = Depends(admin_user), db: Session = Depends(get_db)):
    users = db.query(User).filter(User.is_admin == False).order_by(desc(User.id)).all()
    return [{"id":u.id,"full_name":u.full_name,"phone":u.phone,"is_frozen":u.is_frozen,"created_at":u.created_at.isoformat()} for u in users]

@app.patch("/api/admin/users/{user_id}/freeze")
def admin_freeze_user(user_id: int, data: UserFreezeIn, _: User = Depends(admin_user), db: Session = Depends(get_db)):
    user = db.get(User, user_id)
    if not user or user.is_admin:
        raise HTTPException(status_code=404, detail="User not found")
    user.is_frozen = data.is_frozen
    db.commit()
    return {"ok": True, "is_frozen": user.is_frozen}

@app.get("/api/admin/bookings")
def admin_bookings(_: User = Depends(admin_user), db: Session = Depends(get_db)):
    rows = db.query(BookingTemplate).order_by(BookingTemplate.id).all()
    return [booking_dict(x) for x in rows]

@app.post("/api/admin/bookings")
def admin_create_booking(data: BookingIn, _: User = Depends(admin_user), db: Session = Depends(get_db)):
    item = BookingTemplate(**data.model_dump())
    db.add(item)
    db.commit()
    db.refresh(item)
    return booking_dict(item)

@app.put("/api/admin/bookings/{booking_id}")
def admin_update_booking(booking_id: int, data: BookingIn, _: User = Depends(admin_user), db: Session = Depends(get_db)):
    item = db.get(BookingTemplate, booking_id)
    if not item:
        raise HTTPException(status_code=404, detail="Booking not found")
    for k,v in data.model_dump().items():
        setattr(item, k, v)
    db.commit()
    db.refresh(item)
    return booking_dict(item)

@app.get("/api/admin/reviews")
def admin_reviews(_: User = Depends(admin_user), db: Session = Depends(get_db)):
    rows = db.query(CompletedBooking).order_by(desc(CompletedBooking.id)).limit(100).all()
    out = []
    for x in rows:
        user = db.get(User, x.user_id)
        template = db.get(BookingTemplate, x.template_id)
        out.append({
            "id": x.id,
            "user": user.full_name if user else "Unknown",
            "phone": user.phone if user else "",
            "booking": template.title if template else "Booking",
            "rating": x.rating,
            "review": x.review,
            "completed_at": x.completed_at.isoformat()
        })
    return out

def booking_dict(x: BookingTemplate):
    return {
        "id": x.id, "title": x.title, "location": x.location, "nights": x.nights,
        "guests": x.guests, "room": x.room, "price_lkr": x.price_lkr,
        "image_url": x.image_url, "description": x.description, "is_active": x.is_active
    }
