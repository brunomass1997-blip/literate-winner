import random
from .config import settings

def generate_otp() -> str:
    return f"{random.randint(0, 999999):06d}"

def send_otp(phone: str, code: str) -> None:
    if settings.otp_mode == "dev":
        return

    # PRODUCTION PLACEHOLDER:
    # Connect your SMS provider here.
    # Example providers include Twilio or a local Sri Lankan SMS gateway.
    # Do not hard-code credentials in this file.
    raise RuntimeError("OTP_MODE=sms is enabled but no SMS provider is configured.")
