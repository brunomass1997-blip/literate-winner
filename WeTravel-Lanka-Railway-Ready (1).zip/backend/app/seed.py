from sqlalchemy.orm import Session
from .models import User, BookingTemplate
from .security import hash_password
from .config import settings

DEFAULT_BOOKINGS = [
    ("Ella Mountain Escape","Ella","2 Nights","2 Guests","Deluxe",28500,
     "https://images.unsplash.com/photo-1588598198321-9735fd52455b?auto=format&fit=crop&w=1200&q=85",
     "A peaceful hill-country stay surrounded by misty mountains, tea estates and iconic Ella scenery."),
    ("Mirissa Ocean Retreat","Mirissa","2 Nights","2 Guests","Sea View",32400,
     "https://images.unsplash.com/photo-1586861635167-e5223aadc9fe?auto=format&fit=crop&w=1200&q=85",
     "Relax close to Sri Lanka's southern coastline with easy access to the beach and a calm tropical atmosphere."),
    ("Kandy Heritage Stay","Kandy","1 Night","2 Guests","Premier",21900,
     "https://images.unsplash.com/photo-1591017403286-fd8493524e1e?auto=format&fit=crop&w=1200&q=85",
     "A convenient city stay near Kandy's cultural attractions, lakefront and historic landmarks."),
    ("Sigiriya Nature Lodge","Sigiriya","2 Nights","2 Guests","Garden Villa",30100,
     "https://images.unsplash.com/photo-1588258524675-c6197f36d1e3?auto=format&fit=crop&w=1200&q=85",
     "Stay close to Sri Lanka's Cultural Triangle with nature views and easy access to Sigiriya Rock Fortress."),
    ("Galle Fort Boutique","Galle","2 Nights","2 Guests","Boutique Suite",36500,
     "https://images.unsplash.com/photo-1577717903315-1691ae25ab3f?auto=format&fit=crop&w=1200&q=85",
     "A boutique experience within easy reach of Galle Fort, cafés, galleries and the southern coast.")
]

def seed(db: Session):
    admin = db.query(User).filter(User.phone == settings.admin_phone).first()
    if not admin:
        db.add(User(
            full_name="WeTravel Admin",
            phone=settings.admin_phone,
            password_hash=hash_password(settings.admin_password),
            is_admin=True
        ))
    if db.query(BookingTemplate).count() == 0:
        for row in DEFAULT_BOOKINGS:
            db.add(BookingTemplate(
                title=row[0], location=row[1], nights=row[2], guests=row[3], room=row[4],
                price_lkr=row[5], image_url=row[6], description=row[7], is_active=True
            ))
    db.commit()
