# WeTravel Lanka — Full-Stack Booking & Review Platform

This project upgrades the earlier frontend demo into a runnable full-stack starter.

## Included
- Member registration and login
- Mobile-number based accounts
- JWT authentication
- SQLite database by default
- 20-booking round progress
- One current booking at a time
- Booking completion
- 1–5 star ratings
- Review comments
- Booking history
- Admin login
- User list
- Freeze / unfreeze users
- Booking catalog create/edit/enable/disable
- Review list
- Dev OTP endpoint and provider-ready OTP module
- Responsive WeTravel Lanka dark theme

## Run on Windows
1. Extract the ZIP.
2. Double-click `run_windows.bat`.
3. Open: http://127.0.0.1:8000
4. Admin: http://127.0.0.1:8000/admin.html

Default admin credentials come from `.env.example`:
- Phone: `94770000000`
- Password: `ChangeMe123!`

Change them in `.env` before production use.

## Real OTP
The project uses `OTP_MODE=dev` by default. The OTP is returned only for local testing.
For production, set `OTP_MODE=sms` and connect an SMS gateway in `backend/app/otp_provider.py`.

## Production checklist
- Use PostgreSQL instead of SQLite
- Put the app behind Nginx / HTTPS
- Use a strong SECRET_KEY
- Change admin credentials
- Add rate limiting and audit logging
- Connect a real SMS provider
- Use secure HTTP-only cookie auth if preferred
- Add backups and monitoring
