if(!token()) location.href="/login.html";
let bookings=[];
async function load(){
  try{
    const me=await api("/me",{headers:authHeaders()});if(!me.is_admin){location.href="/";return}
    const [o,u,b,r]=await Promise.all([
      api("/admin/overview",{headers:authHeaders()}),
      api("/admin/users",{headers:authHeaders()}),
      api("/admin/bookings",{headers:authHeaders()}),
      api("/admin/reviews",{headers:authHeaders()})
    ]);
    sUsers.textContent=o.users;sFrozen.textContent=o.frozen_users;sBookings.textContent=o.booking_templates;sReviews.textContent=o.reviews;
    bookings=b;
    userList.innerHTML=u.length?u.map(x=>`<div class="row"><div><strong>${esc(x.full_name)}</strong><br><small>${esc(x.phone)} • ${x.is_frozen?"Frozen":"Active"}</small></div><button class="btn small ${x.is_frozen?"primary":"danger"}" onclick="freezeUser(${x.id},${!x.is_frozen})">${x.is_frozen?"Unfreeze":"Freeze"}</button></div>`).join(""):`<div class="row"><small>No members yet.</small></div>`;
    bookingList.innerHTML=b.map(x=>`<div class="row"><div><strong>${esc(x.title)}</strong><br><small>${esc(x.location)} • ${money(x.price_lkr)} • ${x.is_active?"Active":"Disabled"}</small></div><button class="btn small ghost" onclick="editBooking(${x.id})">Edit</button></div>`).join("");
    reviewList.innerHTML=r.length?r.slice(0,20).map(x=>`<div class="row"><div><strong>${esc(x.user)} — ${esc(x.booking)}</strong><br><small class="stars">${stars(x.rating)}</small><br><small>${esc(x.review)}</small></div></div>`).join(""):`<div class="row"><small>No reviews yet.</small></div>`;
  }catch(e){alert(e.message);location.href="/login.html"}
}
function esc(s){const d=document.createElement("div");d.textContent=s??"";return d.innerHTML}
async function freezeUser(id,is_frozen){try{await api(`/admin/users/${id}/freeze`,{method:"PATCH",headers:authHeaders(),body:JSON.stringify({is_frozen})});toast(is_frozen?"User frozen":"User unfrozen");load()}catch(e){alert(e.message)}}
function editBooking(id){const x=bookings.find(v=>v.id===id);bid.value=x.id;btitle.value=x.title;bloc.value=x.location;bnights.value=x.nights;bguests.value=x.guests;broom.value=x.room;bprice.value=x.price_lkr;bimage.value=x.image_url;bdesc.value=x.description;bactive.checked=x.is_active;formTitle.textContent="Edit Booking";bookingModal.classList.remove("hidden")}
newBooking.onclick=()=>{bookingForm.reset();bid.value="";bactive.checked=true;formTitle.textContent="Add Booking";bookingModal.classList.remove("hidden")};
cancelEdit.onclick=()=>bookingModal.classList.add("hidden");
bookingForm.onsubmit=async(e)=>{e.preventDefault();formError.textContent="";const body={title:btitle.value.trim(),location:bloc.value.trim(),nights:bnights.value.trim(),guests:bguests.value.trim(),room:broom.value.trim(),price_lkr:+bprice.value,image_url:bimage.value.trim(),description:bdesc.value.trim(),is_active:bactive.checked};try{const id=bid.value;if(id)await api(`/admin/bookings/${id}`,{method:"PUT",headers:authHeaders(),body:JSON.stringify(body)});else await api("/admin/bookings",{method:"POST",headers:authHeaders(),body:JSON.stringify(body)});bookingModal.classList.add("hidden");toast("Booking saved");load()}catch(e){formError.textContent=e.message}};
logout.onclick=()=>{localStorage.removeItem("wt_token");location.href="/login.html"};load();
