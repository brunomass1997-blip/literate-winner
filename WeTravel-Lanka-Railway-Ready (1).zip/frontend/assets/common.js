const API = "/api";
const token = () => localStorage.getItem("wt_token");
const authHeaders = () => ({ "Content-Type":"application/json", "Authorization":"Bearer " + token() });
async function api(path, options={}){
  const r = await fetch(API + path, options);
  const data = await r.json().catch(()=>({}));
  if(!r.ok){
    if(r.status===401){ localStorage.removeItem("wt_token"); }
    throw new Error(data.detail || "Request failed");
  }
  return data;
}
function money(v){ return new Intl.NumberFormat("en-LK",{style:"currency",currency:"LKR",maximumFractionDigits:0}).format(v); }
function stars(n){ return "★".repeat(n) + "☆".repeat(5-n); }
function toast(msg){ const t=document.getElementById("toast"); if(!t)return; t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2500); }
