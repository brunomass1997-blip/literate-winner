let dashboard=null, selectedRating=0;
if(!token()) location.href="/login.html";

async function load(){
  try{
    const me=await api("/me",{headers:authHeaders()});
    document.getElementById("memberName").textContent=me.full_name;
    dashboard=await api("/member/dashboard",{headers:authHeaders()});
    render();
  }catch(e){
    alert(e.message);
    if(e.message.includes("token")||e.message.includes("frozen")) location.href="/login.html";
  }
}
function render(){
  completed.textContent=dashboard.completed_count;avg.textContent=dashboard.average_rating.toFixed(1);reviews.textContent=dashboard.reviews_count;round.textContent=dashboard.round_progress;
  const p=Math.round((dashboard.round_progress/20)*100);pct.textContent=p+"%";fill.style.width=p+"%";
  const b=dashboard.current_booking;
  bookingCard.innerHTML=`<div class="booking-image" style="background-image:linear-gradient(180deg,transparent,rgba(0,0,0,.35)),url('${b.image_url}')"></div><div class="booking-content"><span class="loc">📍 ${b.location}, Sri Lanka</span><h3>${b.title}</h3><p>${b.description}</p><div class="meta"><div><small>DURATION</small><strong>${b.nights}</strong></div><div><small>GUESTS</small><strong>${b.guests}</strong></div><div><small>ROOM</small><strong>${b.room}</strong></div></div><div class="price-row"><div><small style="display:block;color:var(--muted)">Booking value</small><strong>${money(b.price_lkr)}</strong></div><button class="btn primary" id="completeBtn">Complete & Review</button></div></div>`;
  completeBtn.onclick=()=>reviewModal.classList.remove("hidden");
  historyBody.innerHTML=dashboard.history.length?dashboard.history.map(x=>`<tr><td>${x.title}</td><td>${x.location}</td><td class="stars">${stars(x.rating)}</td><td>${escapeHtml(x.review)}</td></tr>`).join(""):`<tr><td colspan="4" style="text-align:center;color:var(--muted);padding:30px">No completed bookings yet.</td></tr>`;
}
function escapeHtml(s){const d=document.createElement("div");d.textContent=s;return d.innerHTML;}
document.querySelectorAll("#starPicker button").forEach(b=>b.onclick=()=>{selectedRating=+b.dataset.r;document.querySelectorAll("#starPicker button").forEach(x=>x.classList.toggle("on",+x.dataset.r<=selectedRating));});
document.querySelectorAll("#quickComments button").forEach(b=>b.onclick=()=>{document.querySelectorAll("#quickComments button").forEach(x=>x.classList.remove("selected"));b.classList.add("selected");reviewText.value=b.textContent.trim();});
cancelReview.onclick=()=>reviewModal.classList.add("hidden");
submitReview.onclick=async()=>{reviewError.textContent="";if(!selectedRating){reviewError.textContent="Choose a star rating.";return}if(reviewText.value.trim().length<3){reviewError.textContent="Write or select a review.";return}try{await api("/member/complete-current",{method:"POST",headers:authHeaders(),body:JSON.stringify({rating:selectedRating,review:reviewText.value.trim()})});reviewModal.classList.add("hidden");selectedRating=0;reviewText.value="";await load();toast("Booking completed. Next booking unlocked.");}catch(e){reviewError.textContent=e.message}};
logoutBtn.onclick=()=>{localStorage.removeItem("wt_token");location.href="/login.html"};
load();
